
import React, { useEffect, useState } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import DashboardSidebar from '@/components/dashboard/DashboardSidebar';
import DashboardHeader from '@/components/dashboard/DashboardHeader';
import PublishingCenter from '@/components/dashboard/PublishingCenter';
import { useAuth } from '@/context/AuthContext';
import VoiceGenerator from '@/components/dashboard/VoiceGenerator';
import TemplateLibrary from '@/components/dashboard/TemplateLibrary';
import ScriptGenerator from '@/components/dashboard/ScriptGenerator';
import Analytics from '@/components/dashboard/Analytics';
import CustomBranding from '@/components/dashboard/CustomBranding';
import VideoGenerator from '@/components/dashboard/VideoGenerator';

const Dashboard = () => {
  const { user, loading } = useAuth();
  const location = useLocation();
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  
  // Optimize initial loading by using a shorter loading period for UI
  useEffect(() => {
    if (!loading) {
      // If auth system is ready, stop showing the loading state
      setIsInitialLoading(false);
    } else {
      // If still loading auth state, show loading UI for at most 1 second
      const timer = setTimeout(() => {
        setIsInitialLoading(false);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [loading]);
  
  // Redirect to auth page if not logged in
  if (!loading && !user) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }
  
  // Show optimized loading state
  if (isInitialLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex">
      <DashboardSidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader />
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-6">
          <div className="container mx-auto">
            <Routes>
              <Route path="/" element={<PublishingCenter />} />
              <Route path="/publish" element={<PublishingCenter />} />
              <Route path="/voice-generator" element={<VoiceGenerator />} />
              <Route path="/templates" element={<TemplateLibrary />} />
              <Route path="/script-generator" element={<ScriptGenerator />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/custom-branding" element={<CustomBranding />} />
              <Route path="/video-generator" element={<VideoGenerator />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
