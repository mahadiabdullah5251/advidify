
import React, { useState } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import FeatureSection from '@/components/FeatureSection';
import HowItWorks from '@/components/HowItWorks';
import PricingSection from '@/components/PricingSection';
import Footer from '@/components/Footer';
import { Button } from "@/components/ui/button";
import { useAuth } from '@/context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Index = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const handleCreateVideo = () => {
    if (!user) {
      navigate('/auth');
      return;
    }
    
    navigate('/dashboard/publish');
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <Hero />
      <FeatureSection />
      <HowItWorks />
      <section className="py-16 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 md:px-10">
          <div className="text-center mb-10 animate-fade-in">
            <span className="inline-block px-3 py-1 text-xs font-medium text-primary bg-primary/10 rounded-full mb-4">
              Try It Now
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-balance mb-4">
              Ready to Create Your First Video?
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto mb-8">
              Experience the power of AI-generated UGC videos with our easy-to-use creation tool.
            </p>
            <Button 
              size="lg" 
              className="bg-primary hover:bg-primary/90 transition-all text-white font-medium"
              onClick={handleCreateVideo}
            >
              Create a Video Now
            </Button>
          </div>
        </div>
      </section>
      <PricingSection />
      <Footer />
    </div>
  );
};

export default Index;
