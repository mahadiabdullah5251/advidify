import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { Session, User } from '@supabase/supabase-js';
import { useToast } from '@/hooks/use-toast';

type AuthContextType = {
  session: Session | null;
  user: User | null;
  profile: any | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SESSION_STORAGE_KEY = 'advidify_session';
const USER_STORAGE_KEY = 'advidify_user';
const PROFILE_STORAGE_KEY = 'advidify_profile';

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [session, setSession] = useState<Session | null>(() => {
    const cached = localStorage.getItem(SESSION_STORAGE_KEY);
    return cached ? JSON.parse(cached) : null;
  });
  
  const [user, setUser] = useState<User | null>(() => {
    const cached = localStorage.getItem(USER_STORAGE_KEY);
    return cached ? JSON.parse(cached) : null;
  });
  
  const [profile, setProfile] = useState<any | null>(() => {
    const cached = localStorage.getItem(PROFILE_STORAGE_KEY);
    return cached ? JSON.parse(cached) : null;
  });
  
  const [loading, setLoading] = useState(!session || !user);
  const { toast } = useToast();

  useEffect(() => {
    const getSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (session) {
          setSession(session);
          setUser(session.user);
          localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
          localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(session.user));
          
          if (session.user) {
            await fetchProfile(session.user.id);
          }
        } else {
          localStorage.removeItem(SESSION_STORAGE_KEY);
          localStorage.removeItem(USER_STORAGE_KEY);
          localStorage.removeItem(PROFILE_STORAGE_KEY);
          setSession(null);
          setUser(null);
          setProfile(null);
        }
      } catch (e) {
        console.error('Error getting session:', e);
      } finally {
        setLoading(false);
      }
    };
    
    getSession();
    
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session) {
          localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
          localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(session.user));
          
          if (session.user) {
            await fetchProfile(session.user.id);
          }
        } else {
          localStorage.removeItem(SESSION_STORAGE_KEY);
          localStorage.removeItem(USER_STORAGE_KEY);
          localStorage.removeItem(PROFILE_STORAGE_KEY);
          setProfile(null);
        }
        
        setLoading(false);
      }
    );
    
    return () => {
      subscription?.unsubscribe();
    };
  }, []);
  
  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
        
      if (error) {
        console.error('Error fetching profile:', error);
        return;
      }
      
      setProfile(data);
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error('Error in fetchProfile:', e);
    }
  };
  
  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error };
  };
  
  const signUp = async (email: string, password: string, fullName: string) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
        }
      }
    });
    return { error };
  };
  
  const signOut = async () => {
    await supabase.auth.signOut();
  };
  
  return (
    <AuthContext.Provider value={{
      session,
      user,
      profile,
      loading,
      signIn,
      signUp,
      signOut
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
