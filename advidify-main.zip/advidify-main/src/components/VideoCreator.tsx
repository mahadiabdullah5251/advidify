import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import UploadZone from './UploadZone';
import TemplateCard from './TemplateCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download } from 'lucide-react';
import { toast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

const templates = [
  {
    id: 1,
    title: "Natural Review",
    description: "Authentic user review style with casual filming",
    thumbnail: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7"
  },
  {
    id: 2,
    title: "Product Showcase",
    description: "Clean, professional presentation of features",
    thumbnail: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b"
  },
  {
    id: 3,
    title: "Lifestyle Usage",
    description: "Product shown in everyday situations",
    thumbnail: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  },
  {
    id: 4,
    title: "Problem-Solution",
    description: "Address a pain point and show your solution",
    thumbnail: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6"
  }
];

const voices = [
  { id: 1, name: "Sophia", gender: "Female", tone: "Friendly" },
  { id: 2, name: "Alex", gender: "Male", tone: "Professional" },
  { id: 3, name: "Emma", gender: "Female", tone: "Enthusiastic" },
  { id: 4, name: "James", gender: "Male", tone: "Casual" }
];

const resolutionOptions = [
  { label: "4K (3840x2160)", value: "4k" },
  { label: "1080p (1920x1080)", value: "1080p" },
  { label: "720p (1280x720)", value: "720p" },
  { label: "480p (854x480)", value: "480p" },
];

const VideoCreator = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [productImage, setProductImage] = useState<File | null>(null);
  const [productImagePreview, setProductImagePreview] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null);
  const [selectedVoice, setSelectedVoice] = useState<number | null>(null);
  const [scriptText, setScriptText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoGenerated, setVideoGenerated] = useState(false);
  const [selectedResolution, setSelectedResolution] = useState("1080p");

  const handleImageSelected = (file: File) => {
    setProductImage(file);
    setProductImagePreview(URL.createObjectURL(file));
  };

  const handleTemplateSelect = (id: number) => {
    setSelectedTemplate(id);
  };

  const handleVoiceSelect = (id: number) => {
    setSelectedVoice(id);
  };

  const handleGenerateScript = () => {
    const demoScript = "This product has completely changed my daily routine! I've been using it for about 3 weeks now, and I can honestly say it's worth every penny. The quality is amazing, and it's so easy to use. If you're on the fence about buying it, just go for it - you won't regret it!";
    setScriptText(demoScript);
  };

  const handleNextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleGenerateVideo = () => {
    setIsGenerating(true);
    
    toast({
      title: "Generating Video",
      description: `Your ${selectedResolution} video is being generated...`,
    });
    
    setTimeout(() => {
      setIsGenerating(false);
      setVideoGenerated(true);
      toast({
        title: "Video Generated Successfully",
        description: "Your video is ready to download or share.",
      });
    }, 3000);
  };

  const handleDownloadVideo = () => {
    toast({
      title: "Download Started",
      description: `Downloading your video in ${selectedResolution} resolution.`,
    });
    
    setTimeout(() => {
      toast({
        title: "Download Complete",
        description: "Your video has been saved to your device.",
      });
    }, 1500);
  };

  const isStepComplete = () => {
    switch (currentStep) {
      case 1:
        return !!productImage;
      case 2:
        return selectedTemplate !== null;
      case 3:
        return selectedVoice !== null && scriptText.trim().length > 0;
      default:
        return true;
    }
  };

  return (
    <div className="premium-card rounded-2xl overflow-hidden">
      <div className="p-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Create Your Video Ad</h2>
          <div className="flex items-center">
            <div className="hidden md:flex items-center space-x-2">
              {[1, 2, 3, 4].map((step) => (
                <React.Fragment key={step}>
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      step === currentStep
                        ? 'bg-primary text-white'
                        : step < currentStep
                          ? 'bg-primary/20 text-primary'
                          : 'bg-gray-100 text-gray-400'
                    }`}
                  >
                    {step}
                  </div>
                  {step < 4 && (
                    <div className={`w-12 h-0.5 ${step < currentStep ? 'bg-primary' : 'bg-gray-200'}`} />
                  )}
                </React.Fragment>
              ))}
            </div>
            <span className="text-sm text-gray-500 md:hidden">Step {currentStep} of 4</span>
          </div>
        </div>

        <div className="mb-8">
          {currentStep === 1 && (
            <div className="animate-fade-in">
              <h3 className="text-lg font-medium mb-4">Upload Your Product Image</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <UploadZone onImageSelected={handleImageSelected} />
                
                {productImagePreview && (
                  <div className="flex items-center justify-center">
                    <div className="premium-card p-4 max-w-xs">
                      <div className="aspect-square rounded-lg overflow-hidden">
                        <img 
                          src={productImagePreview} 
                          alt="Product Preview" 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <p className="text-sm text-gray-500 text-center mt-2">Product Preview</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="animate-fade-in">
              <h3 className="text-lg font-medium mb-4">Choose a Template Style</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {templates.map((template) => (
                  <TemplateCard
                    key={template.id}
                    title={template.title}
                    description={template.description}
                    thumbnail={template.thumbnail}
                    isSelected={selectedTemplate === template.id}
                    onSelect={() => handleTemplateSelect(template.id)}
                  />
                ))}
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="animate-fade-in">
              <h3 className="text-lg font-medium mb-4">Select Voice & Script</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <p className="text-sm text-gray-600 mb-3">Choose a voice for your video narration:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    {voices.map((voice) => (
                      <div
                        key={voice.id}
                        className={`p-4 rounded-xl cursor-pointer transition-all ${
                          selectedVoice === voice.id
                            ? 'bg-primary/10 border border-primary'
                            : 'premium-card border border-transparent hover:border-gray-200'
                        }`}
                        onClick={() => handleVoiceSelect(voice.id)}
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{voice.name}</h4>
                          {selectedVoice === voice.id && (
                            <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <polyline points="20 6 9 17 4 12" />
                              </svg>
                            </div>
                          )}
                        </div>
                        <div className="flex items-center text-xs text-gray-500 mt-1 space-x-2">
                          <span>{voice.gender}</span>
                          <span className="w-1 h-1 rounded-full bg-gray-300"></span>
                          <span>{voice.tone}</span>
                        </div>
                        <div className="mt-3 flex items-center">
                          <button className="text-xs text-primary flex items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <polygon points="5 3 19 12 5 21 5 3" />
                            </svg>
                            Preview
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm text-gray-600">Script for your video:</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleGenerateScript}
                      className="text-xs"
                    >
                      Generate with AI
                    </Button>
                  </div>
                  <textarea
                    className="w-full h-40 p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all resize-none"
                    placeholder="Enter or generate a script for your video..."
                    value={scriptText}
                    onChange={(e) => setScriptText(e.target.value)}
                  ></textarea>
                  <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <span>{scriptText.length} characters</span>
                    <span>Recommended: 300-500 characters</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="animate-fade-in">
              <h3 className="text-lg font-medium mb-4">Preview & Generate</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <p className="text-sm text-gray-600 mb-3">Your video settings:</p>
                  <div className="premium-card p-6 rounded-xl">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Template:</span>
                        <span className="text-sm font-medium">
                          {selectedTemplate ? templates.find(t => t.id === selectedTemplate)?.title : 'Not selected'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Voice:</span>
                        <span className="text-sm font-medium">
                          {selectedVoice ? voices.find(v => v.id === selectedVoice)?.name : 'Not selected'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Resolution:</span>
                        <div className="flex items-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-7 text-sm font-medium">
                                {selectedResolution} <span className="ml-1">▼</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              {resolutionOptions.map(option => (
                                <DropdownMenuItem 
                                  key={option.value}
                                  onClick={() => setSelectedResolution(option.value)}
                                >
                                  {option.label}
                                </DropdownMenuItem>
                              ))}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Format:</span>
                        <span className="text-sm font-medium">MP4</span>
                      </div>
                    </div>
                    
                    <div className="mt-6 pt-6 border-t border-gray-100">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Script Preview:</span>
                        <button className="text-xs text-primary">Edit</button>
                      </div>
                      <p className="mt-2 text-sm text-gray-600 line-clamp-4">
                        {scriptText || "No script provided."}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600 mb-3">Generate your video:</p>
                  <div className="premium-card p-6 rounded-xl flex flex-col items-center justify-center text-center">
                    {!videoGenerated ? (
                      <>
                        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M15 10.934a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1v-9z" />
                            <path d="M4 5h7a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z" />
                            <path d="M4 13h7a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1z" />
                          </svg>
                        </div>
                        <h4 className="text-lg font-medium mb-2">Ready to Generate</h4>
                        <p className="text-sm text-gray-500 mb-6">
                          Your video will be generated in {selectedResolution} resolution based on your selections.
                        </p>
                        <Button 
                          className="bg-primary hover:bg-primary/90 w-full"
                          onClick={handleGenerateVideo}
                          disabled={isGenerating}
                        >
                          {isGenerating ? (
                            <>
                              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-t-transparent"></div>
                              Generating...
                            </>
                          ) : (
                            'Generate Video'
                          )}
                        </Button>
                        <p className="mt-3 text-xs text-gray-400">
                          Estimated time: 2-3 minutes
                        </p>
                      </>
                    ) : (
                      <>
                        <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                        <h4 className="text-lg font-medium mb-2">Video Generated!</h4>
                        <div className="aspect-video bg-gray-200 rounded-lg mb-4 overflow-hidden">
                          <div className="h-full flex items-center justify-center text-sm text-gray-500">
                            Preview available
                          </div>
                        </div>
                        <div className="space-y-3 w-full">
                          <Button 
                            className="bg-primary hover:bg-primary/90 w-full flex items-center justify-center"
                            onClick={handleDownloadVideo}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download ({selectedResolution})
                          </Button>
                          
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="outline" className="w-full">
                                Export in Different Resolution
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent className="w-56">
                              {resolutionOptions.map(option => (
                                <DropdownMenuItem 
                                  key={option.value}
                                  onClick={() => {
                                    setSelectedResolution(option.value);
                                    handleDownloadVideo();
                                  }}
                                >
                                  {option.label}
                                </DropdownMenuItem>
                              ))}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePreviousStep}
            disabled={currentStep === 1}
            className={currentStep === 1 ? 'opacity-50 cursor-not-allowed' : ''}
          >
            Previous
          </Button>
          
          <Button
            onClick={handleNextStep}
            disabled={!isStepComplete() || currentStep === 4}
            className={(!isStepComplete() || currentStep === 4) ? 'opacity-50 cursor-not-allowed' : ''}
          >
            {currentStep < 4 ? 'Next' : 'Finish'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VideoCreator;
