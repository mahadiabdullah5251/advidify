
import React from 'react';
import { cn } from '@/lib/utils';

interface TemplateCardProps {
  title: string;
  description: string;
  thumbnail: string;
  isSelected: boolean;
  onSelect: () => void;
  className?: string;
}

const TemplateCard = ({ 
  title, 
  description, 
  thumbnail, 
  isSelected, 
  onSelect, 
  className 
}: TemplateCardProps) => {
  return (
    <div
      className={cn(
        'premium-card rounded-xl overflow-hidden transition-all duration-300 cursor-pointer',
        'hover:translate-y-[-5px] hover:shadow-lg',
        isSelected ? 'ring-2 ring-primary shadow-md' : '',
        className
      )}
      onClick={onSelect}
    >
      <div className="aspect-video relative overflow-hidden">
        <img 
          src={thumbnail} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
          loading="lazy"
        />
        {isSelected && (
          <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="font-medium text-gray-900 mb-1">{title}</h3>
        <p className="text-sm text-gray-500">{description}</p>
      </div>
    </div>
  );
};

export default TemplateCard;
