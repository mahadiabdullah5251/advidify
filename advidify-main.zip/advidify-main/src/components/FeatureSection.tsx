
import React from 'react';

const features = [
  {
    title: "AI Voice Generation",
    description: "Choose from dozens of realistic voices for authentic narration that connects with your audience.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6">
        <path d="M12 18.5a6.5 6.5 0 0 0 6.5-6.5v-6a6.5 6.5 0 1 0-13 0v6a6.5 6.5 0 0 0 6.5 6.5Z" />
        <path d="M8 18.5a4 4 0 0 0 8 0" />
      </svg>
    )
  },
  {
    title: "UGC-Style Templates",
    description: "Access a library of proven UGC templates that mimic authentic user experience videos.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6">
        <rect width="18" height="14" x="3" y="3" rx="2" />
        <circle cx="9" cy="10" r="2" />
        <path d="m15 8 2 2-2 2" />
        <path d="M7 16h10" />
        <path d="M7 20h6" />
      </svg>
    )
  },
  {
    title: "Script Generator",
    description: "AI-powered script generator creates compelling stories around your products that drive conversions.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6">
        <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v5Z" />
        <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1" />
      </svg>
    )
  },
  {
    title: "One-Click Publishing",
    description: "Instantly publish your video ads to all major social platforms with optimized settings for each.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6">
        <path d="M12 20.25c4.97 0 9-3.694 9-8.25s-4.03-8.25-9-8.25S3 7.444 3 12c0 2.104.859 4.023 2.273 5.48.432.447.74 1.04.586 1.641a4.483 4.483 0 0 1-.923 1.785A5.969 5.969 0 0 0 6 21c1.282 0 2.47-.402 3.445-1.087.81.22 1.668.337 2.555.337Z" />
        <path d="m9 12 2 2 4-4" />
      </svg>
    )
  },
  {
    title: "Performance Analytics",
    description: "Track how your AI-generated ads perform against traditional content with detailed metrics.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6">
        <path d="M3 8a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z" />
        <path d="m9 15 3-3 3 3" />
        <path d="m15 10-3 3-3-3" />
      </svg>
    )
  },
  {
    title: "Custom Branding",
    description: "Add your brand colors, logo, and style guidelines to maintain consistent brand identity.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6">
        <path d="M6.5 6.5h11v11h-11z" />
        <rect width="8" height="8" x="8" y="8" rx="1" />
        <path d="m18 16-2-2" />
        <path d="m16 16 2-2" />
        <path d="m8 6 2 2" />
        <path d="m6 8 2-2" />
        <path d="m8 18-2-2" />
        <path d="m8 16-2 2" />
        <path d="m18 8-2-2" />
        <path d="m18 6-2 2" />
      </svg>
    )
  }
];

const FeatureSection = () => {
  return (
    <section id="features" className="py-20 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute left-0 top-1/4 w-64 h-64 bg-blue-50 rounded-full blur-3xl -z-10" />
      <div className="absolute right-0 bottom-1/4 w-72 h-72 bg-purple-50 rounded-full blur-3xl -z-10" />
      
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="text-center mb-16 animate-fade-in">
          <span className="inline-block px-3 py-1 text-xs font-medium text-primary bg-primary/10 rounded-full mb-4">
            Powerful Features
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-balance mb-4">
            Transform Your Product Marketing
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our AI-powered platform makes it easy to create authentic UGC-style video ads that resonate with your audience and drive conversions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="premium-card p-6 relative transition-all duration-300 hover:translate-y-[-5px] animate-fade-in"
              style={{ animationDelay: `${0.1 * index}s` }}
            >
              <div className="absolute -top-3 -left-3 w-12 h-12 flex items-center justify-center rounded-xl bg-primary/10 text-primary">
                {feature.icon}
              </div>
              <div className="pt-8">
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;
