import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { 
  Tabs, 
  TabsList, 
  TabsTrigger, 
  TabsContent 
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Upload, 
  Play, 
  Wand2, 
  RefreshCw, 
  Download,
  Mic,
  FileText,
  PenTool,
  Palette,
  Clock,
  Sparkles,
  Key
} from 'lucide-react';
import { toast } from "@/hooks/use-toast";

const VideoGenerator = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [selectedVoice, setSelectedVoice] = useState<string | null>(null);
  const [productName, setProductName] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [keyBenefits, setKeyBenefits] = useState('');
  const [brandColors, setBrandColors] = useState('#0070f3');
  const [videoLength, setVideoLength] = useState('60');
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [generatedPreview, setGeneratedPreview] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState('');
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);

  useEffect(() => {
    const savedApiKey = localStorage.getItem('geminiApiKey');
    if (savedApiKey) {
      setApiKey(savedApiKey);
      toast({
        title: "API Key Found",
        description: "Your saved Gemini API key has been loaded.",
      });
    } else {
      setShowApiKeyInput(true);
    }
  }, []);

  const templates = [
    { id: 'unboxing', name: 'Unboxing Experience', description: 'Show the product being unboxed with excited reactions' },
    { id: 'before-after', name: 'Before & After', description: 'Demonstrate impressive transformations using your product' },
    { id: 'day-in-life', name: 'Day in the Life', description: 'Show how the product fits into daily routines' },
    { id: 'problem-solution', name: 'Problem-Solution', description: 'Highlight a common problem and how your product solves it' },
    { id: 'testimonial', name: 'Customer Testimonial', description: 'Simulate an authentic customer review' },
  ];

  const voices = [
    { id: 'female-1', name: 'Sarah (Female, American)' },
    { id: 'male-1', name: 'Mike (Male, American)' },
    { id: 'female-2', name: 'Emma (Female, British)' },
    { id: 'male-2', name: 'James (Male, British)' },
    { id: 'female-3', name: 'Sophia (Female, Australian)' },
  ];

  const platforms = [
    { id: 'instagram', name: 'Instagram Reels', format: '9:16', maxLength: '60s' },
    { id: 'tiktok', name: 'TikTok', format: '9:16', maxLength: '60s' },
    { id: 'facebook', name: 'Facebook', format: '16:9', maxLength: '120s' },
    { id: 'youtube', name: 'YouTube Shorts', format: '9:16', maxLength: '60s' },
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      setUploadedImages(prev => [...prev, ...filesArray]);
      
      toast({
        title: "Images Uploaded",
        description: `${filesArray.length} image(s) added to your project.`,
      });
    }
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const saveApiKey = () => {
    if (apiKey) {
      localStorage.setItem('geminiApiKey', apiKey);
      setShowApiKeyInput(false);
      toast({
        title: "API Key Saved",
        description: "Your Gemini API key has been saved securely in your browser.",
      });
    } else {
      toast({
        title: "Missing API Key",
        description: "Please enter your Gemini API key before saving.",
        variant: "destructive",
      });
    }
  };

  const clearApiKey = () => {
    localStorage.removeItem('geminiApiKey');
    setApiKey('');
    setShowApiKeyInput(true);
    toast({
      title: "API Key Removed",
      description: "Your Gemini API key has been removed from storage.",
    });
  };

  const generateVideo = async () => {
    if (!selectedTemplate || !selectedVoice || !productName || !productDescription) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields and select a template and voice.",
        variant: "destructive",
      });
      return;
    }

    if (!apiKey) {
      setShowApiKeyInput(true);
      toast({
        title: "API Key Required",
        description: "Please enter your Gemini API key to generate videos.",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      console.log("Using API key:", apiKey.substring(0, 4) + "..." + apiKey.substring(apiKey.length - 4));
      
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      setGeneratedPreview('https://example.com/generated-video.mp4');
      
      toast({
        title: "Video Generated",
        description: "Your UGC-style video has been successfully generated!",
      });
    } catch (error) {
      console.error("Error generating video:", error);
      toast({
        title: "Generation Failed",
        description: "Failed to generate video. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const downloadVideo = () => {
    if (!generatedPreview) return;
    
    toast({
      title: "Download Started",
      description: "Your video is being downloaded.",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">AI Video Generator</h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={() => setShowApiKeyInput(!showApiKeyInput)}
            className="border-dashed"
          >
            <Key className="h-4 w-4 mr-2" />
            API Key Settings
          </Button>
          
          {generatedPreview && (
            <Button onClick={downloadVideo} className="bg-primary hover:bg-primary/90">
              <Download className="h-4 w-4 mr-2" />
              Download Video
            </Button>
          )}
        </div>
      </div>

      {showApiKeyInput && (
        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-4">Gemini API Configuration</h2>
            <div>
              <Label htmlFor="geminiApiKey">Gemini API Key</Label>
              <div className="flex space-x-2">
                <Input
                  id="geminiApiKey"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your Gemini API key"
                  type="password"
                  className="flex-1"
                />
                <Button 
                  onClick={saveApiKey}
                  disabled={!apiKey}
                  className="bg-primary hover:bg-primary/90"
                >
                  Save Key
                </Button>
                {apiKey && (
                  <Button 
                    onClick={clearApiKey}
                    variant="outline"
                  >
                    Clear
                  </Button>
                )}
              </div>
              <div className="mt-2 text-sm space-y-2">
                <p className="text-gray-500">
                  Your API key is stored only in your browser's local storage and is never sent to our servers.
                </p>
                <p className="flex items-center text-blue-600">
                  <a href="https://ai.google.dev/tutorials/setup" target="_blank" rel="noopener noreferrer" className="flex items-center hover:underline">
                    <Sparkles className="h-3 w-3 mr-1" />
                    How to get a Gemini API key
                  </a>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="setup" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="setup">Setup & Content</TabsTrigger>
          <TabsTrigger value="template">Template Selection</TabsTrigger>
          <TabsTrigger value="voiceover">Voice & Audio</TabsTrigger>
          <TabsTrigger value="branding">Branding & Style</TabsTrigger>
          <TabsTrigger value="preview">Preview & Export</TabsTrigger>
        </TabsList>

        <TabsContent value="setup" className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Product Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="productName">Product Name</Label>
                    <Input
                      id="productName"
                      value={productName}
                      onChange={(e) => setProductName(e.target.value)}
                      placeholder="Enter your product name"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="productDescription">Product Description</Label>
                    <Textarea
                      id="productDescription"
                      value={productDescription}
                      onChange={(e) => setProductDescription(e.target.value)}
                      placeholder="What does your product do? What problem does it solve?"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="targetAudience">Target Audience</Label>
                    <Input
                      id="targetAudience"
                      value={targetAudience}
                      onChange={(e) => setTargetAudience(e.target.value)}
                      placeholder="Who is your ideal customer?"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="keyBenefits">Key Benefits</Label>
                    <Textarea
                      id="keyBenefits"
                      value={keyBenefits}
                      onChange={(e) => setKeyBenefits(e.target.value)}
                      placeholder="List the main benefits of your product"
                      rows={3}
                    />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label className="block mb-2">Product Images</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                      <Upload className="h-10 w-10 mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500 mb-2">
                        Drag and drop images or click to browse
                      </p>
                      <Input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleImageUpload}
                        className="hidden"
                        id="imageUpload"
                      />
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById('imageUpload')?.click()}
                      >
                        Select Images
                      </Button>
                    </div>
                  </div>
                  
                  {uploadedImages.length > 0 && (
                    <div>
                      <Label className="block mb-2">Uploaded Images ({uploadedImages.length})</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {uploadedImages.map((image, index) => (
                          <div key={index} className="relative group">
                            <img
                              src={URL.createObjectURL(image)}
                              alt={`Product ${index + 1}`}
                              className="w-full h-20 object-cover rounded-md"
                            />
                            <button
                              onClick={() => removeImage(index)}
                              className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              ✕
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {showApiKeyInput && (
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">API Configuration</h2>
                <div>
                  <Label htmlFor="geminiApiKey">Gemini API Key</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="geminiApiKey"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      placeholder="Enter your Gemini API key"
                      type="password"
                      className="flex-1"
                    />
                    <Button 
                      onClick={() => {
                        if (apiKey) {
                          setShowApiKeyInput(false);
                          toast({
                            title: "API Key Saved",
                            description: "Your Gemini API key has been saved for this session.",
                          });
                        }
                      }}
                      disabled={!apiKey}
                    >
                      Save
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Your API key is stored only in your browser and never sent to our servers.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="template" className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Select UGC Template</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {templates.map(template => (
                  <div
                    key={template.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${
                      selectedTemplate === template.id ? 'border-primary bg-primary/5 ring-2 ring-primary/20' : 'hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedTemplate(template.id)}
                  >
                    <h3 className="font-medium">{template.name}</h3>
                    <p className="text-sm text-gray-500 mt-1">{template.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Platform Optimization</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {platforms.map(platform => (
                  <div key={platform.id} className="border rounded-lg p-4">
                    <h3 className="font-medium">{platform.name}</h3>
                    <div className="flex justify-between text-sm text-gray-500 mt-1">
                      <span>Format: {platform.format}</span>
                      <span>Max: {platform.maxLength}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="voiceover" className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Select Voice</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {voices.map(voice => (
                  <div
                    key={voice.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${
                      selectedVoice === voice.id ? 'border-primary bg-primary/5 ring-2 ring-primary/20' : 'hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedVoice(voice.id)}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">{voice.name}</h3>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <Play className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Script Generation</h2>
              <div className="space-y-4">
                <p className="text-sm text-gray-500">
                  Our AI will generate a script based on your product information and selected template.
                  You can edit the generated script to customize it to your needs.
                </p>
                <div className="flex space-x-2">
                  <Button 
                    variant="outline"
                    onClick={() => {
                      toast({
                        title: "Script Generated",
                        description: "An AI script has been generated based on your product details.",
                      });
                    }}
                  >
                    <Wand2 className="h-4 w-4 mr-2" />
                    Generate Script
                  </Button>
                  <Button variant="outline">
                    <FileText className="h-4 w-4 mr-2" />
                    Upload Script
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="branding" className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Brand Customization</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="brandColor">Brand Color</Label>
                    <div className="flex space-x-2">
                      <div className="w-10 h-10 rounded-md" style={{ backgroundColor: brandColors }}></div>
                      <Input
                        id="brandColor"
                        type="color"
                        value={brandColors}
                        onChange={(e) => setBrandColors(e.target.value)}
                        className="w-full"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="logoUpload">Logo</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                      <p className="text-sm text-gray-500 mb-2">
                        Upload your brand logo
                      </p>
                      <Input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        id="logoUpload"
                      />
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById('logoUpload')?.click()}
                        size="sm"
                      >
                        Upload Logo
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="videoLength">Video Length</Label>
                    <Select value={videoLength} onValueChange={setVideoLength}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select video length" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 seconds</SelectItem>
                        <SelectItem value="60">60 seconds</SelectItem>
                        <SelectItem value="90">90 seconds</SelectItem>
                        <SelectItem value="120">120 seconds</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label>Style Preferences</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <Button variant="outline" size="sm" className="justify-start">
                        <PenTool className="h-4 w-4 mr-2" /> Natural
                      </Button>
                      <Button variant="outline" size="sm" className="justify-start">
                        <Sparkles className="h-4 w-4 mr-2" /> Energetic
                      </Button>
                      <Button variant="outline" size="sm" className="justify-start">
                        <Palette className="h-4 w-4 mr-2" /> Elegant
                      </Button>
                      <Button variant="outline" size="sm" className="justify-start">
                        <Clock className="h-4 w-4 mr-2" /> Modern
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview" className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Generate & Preview</h2>
              <div className="text-center space-y-6">
                {!generatedPreview ? (
                  <>
                    <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center mb-4">
                      <div className="text-gray-400">Video Preview Will Appear Here</div>
                    </div>
                    <Button 
                      onClick={generateVideo} 
                      className="bg-primary hover:bg-primary/90"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Generating Video...
                        </>
                      ) : (
                        <>
                          <Wand2 className="h-4 w-4 mr-2" />
                          Generate UGC Video
                        </>
                      )}
                    </Button>
                  </>
                ) : (
                  <>
                    <div className="aspect-video bg-gray-800 rounded-lg flex items-center justify-center mb-4 relative">
                      <video 
                        controls 
                        className="w-full h-full rounded-lg"
                        poster="https://via.placeholder.com/1280x720?text=Generated+Video"
                      >
                        <source src={generatedPreview} type="video/mp4" />
                        Your browser does not support the video tag.
                      </video>
                    </div>
                    <div className="flex justify-center space-x-3">
                      <Button onClick={generateVideo} variant="outline" disabled={isLoading}>
                        {isLoading ? (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            Regenerating...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Regenerate
                          </>
                        )}
                      </Button>
                      <Button onClick={downloadVideo} className="bg-primary hover:bg-primary/90">
                        <Download className="h-4 w-4 mr-2" />
                        Download Video
                      </Button>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default VideoGenerator;
