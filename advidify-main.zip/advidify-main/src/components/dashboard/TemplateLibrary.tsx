
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Search, 
  Filter, 
  Play, 
  Copy, 
  Bookmark,
  CheckCircle
} from 'lucide-react';
import { toast } from "@/hooks/use-toast";

// Sample template data
const templatesData = [
  {
    id: 1,
    title: "Product Showcase",
    category: "E-commerce",
    views: 24500,
    conversions: 4.2,
    thumbnail: "https://via.placeholder.com/300x200?text=Product+Showcase",
    tags: ["product", "showcase", "conversion"]
  },
  {
    id: 2,
    title: "Unboxing Experience",
    category: "E-commerce",
    views: 19800,
    conversions: 3.8,
    thumbnail: "https://via.placeholder.com/300x200?text=Unboxing",
    tags: ["unboxing", "review", "first impressions"]
  },
  {
    id: 3,
    title: "Before & After",
    category: "Transformation",
    views: 32100,
    conversions: 5.1,
    thumbnail: "https://via.placeholder.com/300x200?text=Before+After",
    tags: ["transformation", "results", "comparison"]
  },
  {
    id: 4,
    title: "Customer Testimonial",
    category: "Social Proof",
    views: 21400,
    conversions: 4.7,
    thumbnail: "https://via.placeholder.com/300x200?text=Testimonial",
    tags: ["testimonial", "review", "social proof"]
  },
  {
    id: 5,
    title: "Problem-Solution",
    category: "Educational",
    views: 28700,
    conversions: 4.9,
    thumbnail: "https://via.placeholder.com/300x200?text=Problem+Solution",
    tags: ["problem", "solution", "educational"]
  },
  {
    id: 6,
    title: "Day in the Life",
    category: "Lifestyle",
    views: 18200,
    conversions: 3.2,
    thumbnail: "https://via.placeholder.com/300x200?text=Day+in+Life",
    tags: ["lifestyle", "day in life", "routine"]
  },
  {
    id: 7,
    title: "How-To Tutorial",
    category: "Educational",
    views: 29500,
    conversions: 4.5,
    thumbnail: "https://via.placeholder.com/300x200?text=Tutorial",
    tags: ["tutorial", "how-to", "guide"]
  },
  {
    id: 8,
    title: "Product Comparison",
    category: "E-commerce",
    views: 22300,
    conversions: 4.3,
    thumbnail: "https://via.placeholder.com/300x200?text=Comparison",
    tags: ["comparison", "versus", "product review"]
  },
];

// Category filters
const categories = [
  "All Categories",
  "E-commerce",
  "Transformation",
  "Social Proof",
  "Educational",
  "Lifestyle"
];

const TemplateLibrary = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [favorites, setFavorites] = useState<number[]>([]);
  
  const filteredTemplates = templatesData.filter(template => {
    const matchesSearch = template.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          template.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'All Categories' || template.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  const toggleFavorite = (id: number) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(itemId => itemId !== id) : [...prev, id]
    );
  };
  
  const useTemplate = (id: number) => {
    toast({
      title: "Template Selected",
      description: "Template has been added to your project.",
    });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">UGC-Style Templates</h1>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search templates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
          {categories.map(category => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              className={selectedCategory === category ? "bg-primary hover:bg-primary/90" : ""}
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>
      
      {/* Templates Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredTemplates.map(template => (
          <Card key={template.id} className="overflow-hidden">
            <div className="aspect-video relative group">
              <img 
                src={template.thumbnail} 
                alt={template.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  className="bg-white/20 hover:bg-white/30 text-white"
                  onClick={() => toast({
                    title: "Preview",
                    description: `Previewing ${template.title} template.`,
                  })}
                >
                  <Play className="h-4 w-4 mr-1" />
                  Preview
                </Button>
                <Button 
                  size="sm"
                  variant="outline"
                  className="bg-white/20 hover:bg-white/30 text-white"
                  onClick={() => useTemplate(template.id)}
                >
                  <Copy className="h-4 w-4 mr-1" />
                  Use
                </Button>
              </div>
              <button 
                className={`absolute top-2 right-2 p-1 rounded-full ${
                  favorites.includes(template.id) ? 'text-yellow-400' : 'text-white/70 hover:text-white'
                }`}
                onClick={() => toggleFavorite(template.id)}
              >
                <Bookmark className="h-5 w-5 fill-current" />
              </button>
              <div className="absolute bottom-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded-full">
                {template.category}
              </div>
            </div>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">{template.title}</h3>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {template.tags.map((tag, i) => (
                      <span key={i} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex justify-between items-center mt-3 text-sm text-gray-500">
                <div className="flex items-center">
                  <Eye className="h-4 w-4 mr-1" />
                  {(template.views / 1000).toFixed(1)}k
                </div>
                <div className="flex items-center text-green-600">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  {template.conversions}% CVR
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

// Define Eye component since it's used but not imported
const Eye = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

export default TemplateLibrary;
