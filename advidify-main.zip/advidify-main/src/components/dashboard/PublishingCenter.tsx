
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Share } from 'lucide-react';
import { toast } from "@/hooks/use-toast";
import PlatformSelect from './publishing/PlatformSelect';
import VideoPreview from './publishing/VideoPreview';
import PublishingOptions from './publishing/PublishingOptions';
import platforms from './publishing/platformsData';

const PublishingCenter = () => {
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(['instagram', 'tiktok']);
  const [publishNow, setPublishNow] = useState(true);
  const [caption, setCaption] = useState('');
  const [hashtags, setHashtags] = useState('');
  
  const togglePlatform = (platformId: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platformId) 
        ? prev.filter(id => id !== platformId)
        : [...prev, platformId]
    );
  };
  
  const handlePublish = () => {
    if (selectedPlatforms.length === 0) {
      toast({
        title: "No Platforms Selected",
        description: "Please select at least one platform to publish to.",
        variant: "destructive",
      });
      return;
    }
    
    // In a real app, this would call an API to publish to the selected platforms
    const platformNames = selectedPlatforms.map(id => 
      platforms.find(p => p.id === id)?.name
    ).join(', ');
    
    toast({
      title: publishNow ? "Published Successfully" : "Scheduled Successfully",
      description: publishNow 
        ? `Your video has been published to ${platformNames}.`
        : `Your video has been scheduled for publication to ${platformNames}.`,
    });
  };
  
  const handleConnect = (platformId: string) => {
    // In a real app, this would open an OAuth flow
    toast({
      title: "Coming Soon",
      description: `Connection to ${platforms.find(p => p.id === platformId)?.name} will be available soon.`,
    });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Publishing Center</h1>
        <Button 
          onClick={handlePublish} 
          className="bg-primary hover:bg-primary/90"
        >
          <Share className="h-4 w-4 mr-2" />
          {publishNow ? 'Publish Now' : 'Schedule'}
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <VideoPreview 
            caption={caption}
            setCaption={setCaption}
            hashtags={hashtags}
            setHashtags={setHashtags}
          />
          
          <PublishingOptions 
            publishNow={publishNow}
            setPublishNow={setPublishNow}
          />
        </div>
        
        <div>
          <PlatformSelect 
            platforms={platforms}
            selectedPlatforms={selectedPlatforms}
            togglePlatform={togglePlatform}
            handleConnect={handleConnect}
          />
        </div>
      </div>
    </div>
  );
};

export default PublishingCenter;
