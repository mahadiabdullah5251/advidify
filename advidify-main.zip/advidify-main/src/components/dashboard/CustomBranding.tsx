
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent
} from "@/components/ui/tabs";
import {
  Palette,
  Image,
  Type,
  Save,
  RefreshCw
} from 'lucide-react';
import { toast } from "@/hooks/use-toast";

const CustomBranding = () => {
  // Brand Colors
  const [primaryColor, setPrimaryColor] = useState('#9b87f5');
  const [secondaryColor, setSecondaryColor] = useState('#6E59A5');
  const [accentColor, setAccentColor] = useState('#D6BCFA');
  const [textColor, setTextColor] = useState('#1A1F2C');
  
  // Brand Assets
  const [logo, setLogo] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [watermark, setWatermark] = useState<File | null>(null);
  const [watermarkPreview, setWatermarkPreview] = useState<string | null>(null);
  
  // Typography
  const [headingFont, setHeadingFont] = useState('Inter');
  const [bodyFont, setBodyFont] = useState('Inter');
  
  // Form state
  const [isSaving, setIsSaving] = useState(false);
  
  // Preview template style
  const previewStyle = {
    backgroundColor: primaryColor,
    color: textColor,
    fontFamily: bodyFont,
  };
  
  const headingStyle = {
    color: textColor,
    fontFamily: headingFont,
  };
  
  const buttonStyle = {
    backgroundColor: secondaryColor,
    color: '#ffffff',
  };
  
  const accentStyle = {
    backgroundColor: accentColor,
  };
  
  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      setLogo(file);
      setLogoPreview(URL.createObjectURL(file));
    }
  };
  
  const handleWatermarkChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      setWatermark(file);
      setWatermarkPreview(URL.createObjectURL(file));
    }
  };
  
  const handleSave = async () => {
    setIsSaving(true);
    
    // In a real app, this would send the branding settings to your backend
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast({
      title: "Branding Saved",
      description: "Your custom branding settings have been saved.",
    });
    
    setIsSaving(false);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Custom Branding</h1>
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-primary hover:bg-primary/90"
        >
          {isSaving ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Branding
            </>
          )}
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Tabs defaultValue="colors">
            <TabsList className="mb-6">
              <TabsTrigger value="colors">
                <Palette className="h-4 w-4 mr-2" />
                Colors
              </TabsTrigger>
              <TabsTrigger value="assets">
                <Image className="h-4 w-4 mr-2" />
                Assets
              </TabsTrigger>
              <TabsTrigger value="typography">
                <Type className="h-4 w-4 mr-2" />
                Typography
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="colors" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-6 rounded-xl border border-gray-200">
                <div>
                  <Label htmlFor="primaryColor">Primary Color</Label>
                  <div className="flex mt-1">
                    <div 
                      className="w-10 h-10 rounded-l-md border border-r-0 border-gray-300"
                      style={{ backgroundColor: primaryColor }}
                    ></div>
                    <Input
                      id="primaryColor"
                      type="text"
                      value={primaryColor}
                      onChange={(e) => setPrimaryColor(e.target.value)}
                      className="rounded-l-none"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="secondaryColor">Secondary Color</Label>
                  <div className="flex mt-1">
                    <div 
                      className="w-10 h-10 rounded-l-md border border-r-0 border-gray-300"
                      style={{ backgroundColor: secondaryColor }}
                    ></div>
                    <Input
                      id="secondaryColor"
                      type="text"
                      value={secondaryColor}
                      onChange={(e) => setSecondaryColor(e.target.value)}
                      className="rounded-l-none"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="accentColor">Accent Color</Label>
                  <div className="flex mt-1">
                    <div 
                      className="w-10 h-10 rounded-l-md border border-r-0 border-gray-300"
                      style={{ backgroundColor: accentColor }}
                    ></div>
                    <Input
                      id="accentColor"
                      type="text"
                      value={accentColor}
                      onChange={(e) => setAccentColor(e.target.value)}
                      className="rounded-l-none"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="textColor">Text Color</Label>
                  <div className="flex mt-1">
                    <div 
                      className="w-10 h-10 rounded-l-md border border-r-0 border-gray-300"
                      style={{ backgroundColor: textColor }}
                    ></div>
                    <Input
                      id="textColor"
                      type="text"
                      value={textColor}
                      onChange={(e) => setTextColor(e.target.value)}
                      className="rounded-l-none"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="assets" className="space-y-4">
              <div className="bg-white p-6 rounded-xl border border-gray-200 space-y-6">
                <div>
                  <Label htmlFor="logo">Company Logo</Label>
                  <div className="mt-1 flex items-center space-x-4">
                    <div className="w-24 h-24 border border-gray-300 rounded-md flex items-center justify-center overflow-hidden">
                      {logoPreview ? (
                        <img src={logoPreview} alt="Logo Preview" className="max-w-full max-h-full" />
                      ) : (
                        <span className="text-gray-400">No logo</span>
                      )}
                    </div>
                    <Input
                      id="logo"
                      type="file"
                      accept="image/*"
                      onChange={handleLogoChange}
                      className="max-w-xs"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="watermark">Video Watermark</Label>
                  <div className="mt-1 flex items-center space-x-4">
                    <div className="w-24 h-24 border border-gray-300 rounded-md flex items-center justify-center overflow-hidden">
                      {watermarkPreview ? (
                        <img src={watermarkPreview} alt="Watermark Preview" className="max-w-full max-h-full" />
                      ) : (
                        <span className="text-gray-400">No watermark</span>
                      )}
                    </div>
                    <Input
                      id="watermark"
                      type="file"
                      accept="image/*"
                      onChange={handleWatermarkChange}
                      className="max-w-xs"
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="typography" className="space-y-4">
              <div className="bg-white p-6 rounded-xl border border-gray-200 space-y-6">
                <div>
                  <Label htmlFor="headingFont">Heading Font</Label>
                  <select
                    id="headingFont"
                    value={headingFont}
                    onChange={(e) => setHeadingFont(e.target.value)}
                    className="w-full mt-1 border border-gray-300 rounded-md p-2"
                  >
                    <option value="Inter">Inter</option>
                    <option value="Roboto">Roboto</option>
                    <option value="Poppins">Poppins</option>
                    <option value="Montserrat">Montserrat</option>
                    <option value="Open Sans">Open Sans</option>
                  </select>
                </div>
                
                <div>
                  <Label htmlFor="bodyFont">Body Font</Label>
                  <select
                    id="bodyFont"
                    value={bodyFont}
                    onChange={(e) => setBodyFont(e.target.value)}
                    className="w-full mt-1 border border-gray-300 rounded-md p-2"
                  >
                    <option value="Inter">Inter</option>
                    <option value="Roboto">Roboto</option>
                    <option value="Poppins">Poppins</option>
                    <option value="Montserrat">Montserrat</option>
                    <option value="Open Sans">Open Sans</option>
                  </select>
                </div>
                
                <div className="pt-4">
                  <Label>Typography Preview</Label>
                  <div className="mt-2 p-4 border border-gray-300 rounded-md" style={{ fontFamily: bodyFont }}>
                    <h1 style={{ ...headingStyle, fontSize: '1.5rem', fontWeight: 'bold' }}>Heading 1 Example</h1>
                    <h2 style={{ ...headingStyle, fontSize: '1.25rem', fontWeight: 'bold', marginTop: '0.5rem' }}>Heading 2 Example</h2>
                    <p style={{ marginTop: '0.5rem' }}>This is an example of body text using the selected font. It demonstrates how paragraphs will appear in your videos with the current branding settings.</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        <div>
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div className="aspect-video" style={previewStyle}>
                <div className="relative w-full h-full p-4 flex flex-col justify-between">
                  {/* Simulated video content */}
                  <div className="flex justify-between items-start">
                    {logoPreview && (
                      <div className="w-16 h-16 overflow-hidden rounded-md bg-white/90 flex items-center justify-center p-1">
                        <img src={logoPreview} alt="Logo" className="max-w-full max-h-full" />
                      </div>
                    )}
                    
                    <div 
                      className="rounded-md px-2 py-1 text-xs font-medium"
                      style={accentStyle}
                    >
                      PREVIEW
                    </div>
                  </div>
                  
                  <div className="mt-auto">
                    <h3 style={headingStyle} className="text-xl font-bold">Your Product Name</h3>
                    <p className="text-sm mt-1 opacity-90">This is how your videos will look with your branding applied.</p>
                    
                    <Button className="mt-3" style={buttonStyle}>
                      Shop Now
                    </Button>
                    
                    {watermarkPreview && (
                      <div className="absolute bottom-4 right-4 w-10 h-10 opacity-70">
                        <img src={watermarkPreview} alt="Watermark" className="max-w-full max-h-full" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="mt-6 bg-white p-6 rounded-xl border border-gray-200">
            <h2 className="text-lg font-semibold mb-3">Branding Tips</h2>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• Use colors that match your existing brand identity</li>
              <li>• Choose fonts that are easy to read in videos</li>
              <li>• Keep your logo and watermark simple and recognizable</li>
              <li>• Test your branding on different video templates</li>
              <li>• Ensure sufficient contrast between text and background colors</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomBranding;
