
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Pause, Check } from 'lucide-react';

interface Voice {
  id: string;
  name: string;
  gender: string;
  accent: string;
  sample: string;
}

interface VoiceSelectorProps {
  voices: Voice[];
  selectedVoice: string | null;
  onSelectVoice: (voiceId: string) => void;
  playingVoice: string | null;
  onPlaySample: (voiceId: string) => void;
  onPauseSample: () => void;
}

const VoiceSelector = ({
  voices,
  selectedVoice,
  onSelectVoice,
  playingVoice,
  onPlaySample,
  onPauseSample
}: VoiceSelectorProps) => {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Select a Voice</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {voices.map((voice) => (
          <Card 
            key={voice.id} 
            className={`overflow-hidden transition-all ${
              selectedVoice === voice.id ? 'ring-2 ring-primary' : 'hover:border-primary/50'
            }`}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center mb-3">
                <div>
                  <h3 className="font-medium">{voice.name}</h3>
                  <p className="text-sm text-gray-500">{voice.gender} • {voice.accent}</p>
                </div>
                <Button
                  size="sm"
                  variant={selectedVoice === voice.id ? "default" : "outline"}
                  onClick={() => onSelectVoice(voice.id)}
                  className={selectedVoice === voice.id ? "bg-primary" : ""}
                >
                  {selectedVoice === voice.id && <Check className="h-4 w-4 mr-1" />}
                  {selectedVoice === voice.id ? "Selected" : "Select"}
                </Button>
              </div>
              <div className="flex justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (playingVoice === voice.id) {
                      onPauseSample();
                    } else {
                      onPlaySample(voice.id);
                    }
                  }}
                >
                  {playingVoice === voice.id ? (
                    <>
                      <Pause className="h-4 w-4 mr-1" />
                      Pause Sample
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-1" />
                      Play Sample
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default VoiceSelector;
