
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Mic, Play, Pause, Download, RefreshCw } from 'lucide-react';
import { toast } from "@/hooks/use-toast";

interface TextToVoiceConverterProps {
  selectedVoice: string | null;
  onGenerateAudio: (text: string, voiceId: string) => Promise<string>;
}

const TextToVoiceConverter = ({
  selectedVoice,
  onGenerateAudio
}: TextToVoiceConverterProps) => {
  const [text, setText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const handleGenerate = async () => {
    if (!selectedVoice) {
      toast({
        title: "No Voice Selected",
        description: "Please select a voice first.",
        variant: "destructive",
      });
      return;
    }

    if (!text.trim()) {
      toast({
        title: "No Text Input",
        description: "Please enter some text to convert to speech.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsGenerating(true);
      const audioData = await onGenerateAudio(text, selectedVoice);
      
      // Create audio element
      if (audioElement) {
        audioElement.pause();
      }
      
      const newAudio = new Audio(audioData);
      setAudioElement(newAudio);
      setAudioUrl(audioData);
      
      toast({
        title: "Audio Generated",
        description: "Your audio has been successfully generated!",
      });
      
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: "Failed to generate audio. Please try again.",
        variant: "destructive",
      });
      console.error("Error generating audio:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePlayPause = () => {
    if (!audioElement) return;
    
    if (isPlaying) {
      audioElement.pause();
      setIsPlaying(false);
    } else {
      audioElement.play();
      setIsPlaying(true);
      
      audioElement.onended = () => {
        setIsPlaying(false);
      };
    }
  };

  const handleDownload = () => {
    if (!audioUrl) return;
    
    const link = document.createElement('a');
    link.href = audioUrl;
    link.download = 'generated-audio.mp3';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Download Started",
      description: "Your audio file is being downloaded.",
    });
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Convert Text to Speech</h2>
      
      <div className="space-y-4">
        <textarea
          value={text}
          onChange={handleTextChange}
          placeholder="Enter the text you want to convert to speech..."
          className="w-full h-40 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
        />
        
        <div className="flex flex-wrap gap-3">
          <Button
            onClick={handleGenerate}
            disabled={isGenerating || !selectedVoice}
            className="bg-primary hover:bg-primary/90"
          >
            {isGenerating ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Mic className="h-4 w-4 mr-2" />}
            {isGenerating ? 'Generating...' : 'Generate Audio'}
          </Button>
          
          {audioUrl && (
            <>
              <Button
                onClick={handlePlayPause}
                variant="outline"
              >
                {isPlaying ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                {isPlaying ? 'Pause' : 'Play'}
              </Button>
              
              <Button
                onClick={handleDownload}
                variant="outline"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default TextToVoiceConverter;
