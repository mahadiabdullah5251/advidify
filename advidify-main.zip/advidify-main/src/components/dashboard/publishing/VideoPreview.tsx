
import React, { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Download, Check } from 'lucide-react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { VideoPreviewProps } from './types';
import { toast } from "@/hooks/use-toast";

const VideoPreview = ({ 
  caption, 
  setCaption, 
  hashtags, 
  setHashtags 
}: VideoPreviewProps) => {
  const [selectedResolution, setSelectedResolution] = useState<string>("1080p");
  const [isExporting, setIsExporting] = useState(false);
  
  const resolutionOptions = [
    { label: "4K (3840x2160)", value: "4k" },
    { label: "1080p (1920x1080)", value: "1080p" },
    { label: "720p (1280x720)", value: "720p" },
    { label: "480p (854x480)", value: "480p" },
  ];

  const handleExportVideo = () => {
    try {
      // In a real app, this would call an API to generate and download the video
      setIsExporting(true);
      toast({
        title: "Video Export Started",
        description: `Your video is being prepared in ${selectedResolution} resolution.`,
      });
      
      // Simulate download after 2 seconds
      setTimeout(() => {
        setIsExporting(false);
        toast({
          title: "Video Ready",
          description: "Your video has been generated and is ready to download.",
        });
      }, 2000);
    } catch (error) {
      setIsExporting(false);
      toast({
        title: "Export Failed",
        description: "There was an error exporting your video. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium">Video Preview</h2>
        <div className="flex space-x-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                {selectedResolution} <span className="ml-2">▼</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {resolutionOptions.map((option) => (
                <DropdownMenuItem 
                  key={option.value}
                  onClick={() => setSelectedResolution(option.value)}
                  className="flex items-center justify-between"
                >
                  {option.label}
                  {selectedResolution === option.value && (
                    <Check className="h-4 w-4 ml-2" />
                  )}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button 
            onClick={handleExportVideo}
            size="sm"
            className="bg-primary hover:bg-primary/90"
            disabled={isExporting}
          >
            <Download className="h-4 w-4 mr-2" />
            {isExporting ? 'Exporting...' : 'Export'}
          </Button>
        </div>
      </div>
      
      <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center mb-4">
        <div className="text-gray-400">Video Preview</div>
      </div>
      
      <div className="mt-4">
        <Label htmlFor="caption">Caption</Label>
        <textarea
          id="caption"
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="Write a caption for your video..."
          rows={3}
          className="w-full p-3 mt-1 border border-gray-200 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all resize-none"
        ></textarea>
      </div>
      
      <div className="mt-4">
        <Label htmlFor="hashtags">Hashtags</Label>
        <Input
          id="hashtags"
          value={hashtags}
          onChange={(e) => setHashtags(e.target.value)}
          placeholder="e.g., #product #ugc #review"
          className="mt-1"
        />
      </div>
    </div>
  );
};

export default VideoPreview;
