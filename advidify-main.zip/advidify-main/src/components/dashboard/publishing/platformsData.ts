
import { 
  Instagram, 
  Youtube, 
  Music, // Using Music icon instead of TikTok (which doesn't exist in lucide-react)
  Twitter, 
  Facebook, 
  Linkedin 
} from 'lucide-react';
import { Platform } from './types';

const platforms: Platform[] = [
  {
    id: 'instagram',
    name: 'Instagram',
    icon: Instagram,
    color: '#E1306C',
    connected: true
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    icon: Music, // Using Music icon as a substitute for TikTok
    color: '#000000',
    connected: true
  },
  {
    id: 'youtube',
    name: 'YouTube',
    icon: Youtube,
    color: '#FF0000',
    connected: false
  },
  {
    id: 'twitter',
    name: 'Twitter',
    icon: Twitter,
    color: '#1DA1F2',
    connected: false
  },
  {
    id: 'facebook',
    name: 'Facebook',
    icon: Facebook,
    color: '#4267B2',
    connected: false
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    icon: Linkedin,
    color: '#0077B5',
    connected: false
  }
];

export default platforms;
