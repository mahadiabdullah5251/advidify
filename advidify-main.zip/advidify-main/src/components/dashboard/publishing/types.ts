
import { ReactElement } from 'react';

export interface Platform {
  id: string;
  name: string;
  icon: React.ElementType;
  color: string;
  connected: boolean;
}

export interface PlatformSelectProps {
  platforms: Platform[];
  selectedPlatforms: string[];
  togglePlatform: (platformId: string) => void;
  handleConnect: (platformId: string) => void;
}

export interface PublishingOptionsProps {
  publishNow: boolean;
  setPublishNow: (value: boolean) => void;
}

export interface VideoPreviewProps {
  caption: string;
  setCaption: (value: string) => void;
  hashtags: string;
  setHashtags: (value: string) => void;
}

export interface ResolutionOption {
  label: string;
  value: string;
}
