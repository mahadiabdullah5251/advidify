
import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';
import { toast } from "@/hooks/use-toast";
import { PlatformSelectProps } from './types';

const PlatformSelect = ({ 
  platforms, 
  selectedPlatforms, 
  togglePlatform, 
  handleConnect 
}: PlatformSelectProps) => {
  if (!platforms || platforms.length === 0) {
    return (
      <div className="bg-white border border-gray-200 rounded-xl p-6">
        <p className="text-gray-500">No platforms available</p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-lg font-medium mb-4">Platforms</h2>
      <div className="space-y-3">
        {platforms.map(platform => {
          const isConnected = platform.connected;
          const isSelected = selectedPlatforms.includes(platform.id);
          
          return (
            <div 
              key={platform.id}
              className={`p-4 rounded-xl border transition-all ${
                isConnected
                  ? isSelected
                    ? 'border-primary bg-primary/5'
                    : 'border-gray-200 hover:border-primary/50'
                  : 'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-white" style={{ backgroundColor: platform.color }}>
                    <platform.icon className="h-5 w-5" />
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium">{platform.name}</h3>
                    <p className="text-xs text-gray-500">
                      {isConnected ? 'Connected' : 'Not connected'}
                    </p>
                  </div>
                </div>
                
                {isConnected ? (
                  <Button
                    variant="ghost"
                    size="sm"
                    className={isSelected ? 'text-primary hover:text-primary/80' : ''}
                    onClick={() => togglePlatform(platform.id)}
                  >
                    {isSelected ? 'Selected' : 'Select'}
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleConnect(platform.id)}
                  >
                    Connect
                  </Button>
                )}
              </div>
            </div>
          );
        })}
        
        <Button
          variant="outline"
          className="w-full justify-center mt-4"
          onClick={() => toast({ title: "Coming Soon", description: "Additional platform connections will be available soon." })}
        >
          Add More Platforms
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default PlatformSelect;
