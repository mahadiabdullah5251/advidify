
import React from 'react';
import { Button } from "@/components/ui/button";
import { Clock, Calendar } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PublishingOptionsProps } from './types';

const PublishingOptions = ({ 
  publishNow, 
  setPublishNow 
}: PublishingOptionsProps) => {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6">
      <h2 className="text-lg font-medium mb-4">Publishing Options</h2>
      
      <div className="flex space-x-4 mb-6">
        <Button
          variant={publishNow ? "default" : "outline"}
          className={publishNow ? "bg-primary hover:bg-primary/90" : ""}
          onClick={() => setPublishNow(true)}
        >
          <Clock className="h-4 w-4 mr-2" />
          Publish Now
        </Button>
        
        <Button
          variant={!publishNow ? "default" : "outline"}
          className={!publishNow ? "bg-primary hover:bg-primary/90" : ""}
          onClick={() => setPublishNow(false)}
        >
          <Calendar className="h-4 w-4 mr-2" />
          Schedule
        </Button>
      </div>
      
      {!publishNow && (
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <Label htmlFor="schedule-date">Date</Label>
            <Input
              id="schedule-date"
              type="date"
              className="mt-1"
              min={new Date().toISOString().split('T')[0]}
            />
          </div>
          <div>
            <Label htmlFor="schedule-time">Time</Label>
            <Input
              id="schedule-time"
              type="time"
              className="mt-1"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default PublishingOptions;
