
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader,
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent
} from "@/components/ui/tabs";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  TrendingUp,
  Eye,
  ThumbsUp,
  Share2,
  ShoppingCart,
  Calendar,
  ChevronDown,
  Download
} from 'lucide-react';
import { toast } from "@/hooks/use-toast";

// Sample data for charts
const viewsData = [
  { date: 'Mon', ai: 2400, traditional: 1398 },
  { date: 'Tue', ai: 1398, traditional: 987 },
  { date: 'Wed', ai: 3800, traditional: 1200 },
  { date: 'Thu', ai: 3908, traditional: 1600 },
  { date: 'Fri', ai: 4800, traditional: 1908 },
  { date: 'Sat', ai: 3800, traditional: 1800 },
  { date: 'Sun', ai: 4300, traditional: 2100 },
];

const engagementData = [
  { name: 'Likes', ai: 65, traditional: 35 },
  { name: 'Comments', ai: 70, traditional: 30 },
  { name: 'Shares', ai: 80, traditional: 20 },
  { name: 'Saves', ai: 60, traditional: 40 },
];

const platformData = [
  { name: 'Instagram', value: 45 },
  { name: 'TikTok', value: 30 },
  { name: 'Facebook', value: 15 },
  { name: 'YouTube', value: 10 },
];

const conversionData = [
  { month: 'Jan', ai: 4.2, traditional: 2.8 },
  { month: 'Feb', ai: 4.8, traditional: 3.1 },
  { month: 'Mar', ai: 5.3, traditional: 3.2 },
  { month: 'Apr', ai: 5.7, traditional: 3.3 },
  { month: 'May', ai: 6.1, traditional: 3.4 },
  { month: 'Jun', ai: 6.5, traditional: 3.5 },
];

const COLORS = ['#9b87f5', '#6E59A5', '#D6BCFA', '#1A1F2C'];

const Analytics = () => {
  const [dateRange, setDateRange] = useState('7d');
  
  const handleExportData = () => {
    toast({
      title: "Report Exported",
      description: "Your analytics report has been exported as CSV.",
    });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold">Performance Analytics</h1>
        
        <div className="flex flex-wrap gap-2">
          <div className="flex">
            <Button variant="outline" className="rounded-r-none border-r-0">
              {dateRange === '7d' ? 'Last 7 Days' : 
               dateRange === '30d' ? 'Last 30 Days' : 
               dateRange === '90d' ? 'Last 90 Days' : 'Custom Range'}
              <ChevronDown className="h-4 w-4 ml-2" />
            </Button>
            <Button variant="outline" className="rounded-l-none px-3" onClick={() => setDateRange('7d')}>
              <Calendar className="h-4 w-4" />
            </Button>
          </div>
          
          <Button variant="outline" onClick={handleExportData}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Views</p>
                <h3 className="text-2xl font-bold mt-1">247,892</h3>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +24.3% vs. traditional
                </p>
              </div>
              <div className="bg-primary/10 p-3 rounded-full">
                <Eye className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Engagement Rate</p>
                <h3 className="text-2xl font-bold mt-1">7.4%</h3>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +32.1% vs. traditional
                </p>
              </div>
              <div className="bg-primary/10 p-3 rounded-full">
                <ThumbsUp className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Share Rate</p>
                <h3 className="text-2xl font-bold mt-1">3.8%</h3>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +41.9% vs. traditional
                </p>
              </div>
              <div className="bg-primary/10 p-3 rounded-full">
                <Share2 className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Conversion Rate</p>
                <h3 className="text-2xl font-bold mt-1">5.9%</h3>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +47.5% vs. traditional
                </p>
              </div>
              <div className="bg-primary/10 p-3 rounded-full">
                <ShoppingCart className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Detailed Analytics */}
      <Tabs defaultValue="overview">
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="platform">By Platform</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="conversion">Conversion</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Views Comparison</CardTitle>
                <CardDescription>AI-generated vs. Traditional content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={viewsData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="ai" stroke="#9b87f5" name="AI-Generated" strokeWidth={2} />
                      <Line type="monotone" dataKey="traditional" stroke="#cccccc" name="Traditional" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Engagement Metrics</CardTitle>
                <CardDescription>AI-generated vs. Traditional content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={engagementData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="ai" name="AI-Generated" fill="#9b87f5" />
                      <Bar dataKey="traditional" name="Traditional" fill="#cccccc" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="platform">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Platform Distribution</CardTitle>
                <CardDescription>Views by platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={platformData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {platformData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card className="lg:row-span-2">
              <CardHeader className="pb-2">
                <CardTitle>Platform Performance</CardTitle>
                <CardDescription>Key metrics by platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Instagram</h4>
                      <span className="text-green-600 text-sm">+28.3%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-[#E1306C]" style={{ width: '78%' }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Views: 98,432</span>
                      <span>Conv: 4.8%</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">TikTok</h4>
                      <span className="text-green-600 text-sm">+41.9%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-black" style={{ width: '85%' }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Views: 82,765</span>
                      <span>Conv: 5.3%</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Facebook</h4>
                      <span className="text-green-600 text-sm">+18.7%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-[#4267B2]" style={{ width: '62%' }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Views: 37,284</span>
                      <span>Conv: 3.8%</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">YouTube</h4>
                      <span className="text-green-600 text-sm">+24.1%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-[#FF0000]" style={{ width: '70%' }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Views: 29,411</span>
                      <span>Conv: 4.2%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="engagement">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Engagement Breakdown</CardTitle>
                <CardDescription>Detailed engagement metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="bg-primary/10 p-2 rounded-full mr-3">
                        <ThumbsUp className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">Likes</p>
                        <p className="text-sm text-gray-500">Total engagement</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold">42,769</p>
                      <p className="text-sm text-green-600">+32.1%</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="bg-primary/10 p-2 rounded-full mr-3">
                        <Share2 className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">Shares</p>
                        <p className="text-sm text-gray-500">Total engagement</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold">9,418</p>
                      <p className="text-sm text-green-600">+41.9%</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="bg-primary/10 p-2 rounded-full mr-3">
                        <MessageSquare className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">Comments</p>
                        <p className="text-sm text-gray-500">Total engagement</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold">8,275</p>
                      <p className="text-sm text-green-600">+27.5%</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="bg-primary/10 p-2 rounded-full mr-3">
                        <Bookmark className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">Saves</p>
                        <p className="text-sm text-gray-500">Total engagement</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold">6,932</p>
                      <p className="text-sm text-green-600">+35.2%</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Audience Demographics</CardTitle>
                <CardDescription>Who is engaging with your content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-2">Age Distribution</h4>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <span className="w-12 text-xs">18-24</span>
                        <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-primary" style={{ width: '35%' }}></div>
                        </div>
                        <span className="w-12 text-right text-xs">35%</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-12 text-xs">25-34</span>
                        <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-primary" style={{ width: '42%' }}></div>
                        </div>
                        <span className="w-12 text-right text-xs">42%</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-12 text-xs">35-44</span>
                        <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-primary" style={{ width: '15%' }}></div>
                        </div>
                        <span className="w-12 text-right text-xs">15%</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-12 text-xs">45+</span>
                        <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-primary" style={{ width: '8%' }}></div>
                        </div>
                        <span className="w-12 text-right text-xs">8%</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-2">Gender</h4>
                    <div className="flex gap-4">
                      <div className="flex-1 p-3 bg-primary/10 rounded-lg text-center">
                        <p className="text-xl font-bold">58%</p>
                        <p className="text-sm">Female</p>
                      </div>
                      <div className="flex-1 p-3 bg-gray-100 rounded-lg text-center">
                        <p className="text-xl font-bold">42%</p>
                        <p className="text-sm">Male</p>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-2">Top Locations</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>United States</span>
                        <span>45%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>United Kingdom</span>
                        <span>18%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Canada</span>
                        <span>12%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Australia</span>
                        <span>8%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="conversion">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Conversion Rate Comparison</CardTitle>
                <CardDescription>AI-generated vs. Traditional content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={conversionData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                      <Line type="monotone" dataKey="ai" stroke="#9b87f5" name="AI-Generated" strokeWidth={2} />
                      <Line type="monotone" dataKey="traditional" stroke="#cccccc" name="Traditional" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Revenue Impact</CardTitle>
                <CardDescription>Estimated revenue from conversions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-gray-500">Total Revenue</p>
                        <p className="text-3xl font-bold">$547,892</p>
                      </div>
                      <div className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded-md">
                        +32.5% vs prev.
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-500">AI-Generated</p>
                      <p className="text-2xl font-bold">$328,735</p>
                      <p className="text-sm text-green-600">+42.3%</p>
                    </div>
                    
                    <div className="bg-gray-100 p-4 rounded-lg">
                      <p className="text-sm text-gray-500">Traditional</p>
                      <p className="text-2xl font-bold">$219,157</p>
                      <p className="text-sm text-green-600">+18.7%</p>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-2">Revenue by Product Category</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Apparel</span>
                        <div className="flex items-center">
                          <span className="mr-2">$187,452</span>
                          <span className="text-xs text-green-600">+38%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Accessories</span>
                        <div className="flex items-center">
                          <span className="mr-2">$142,183</span>
                          <span className="text-xs text-green-600">+27%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Footwear</span>
                        <div className="flex items-center">
                          <span className="mr-2">$115,926</span>
                          <span className="text-xs text-green-600">+41%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Beauty</span>
                        <div className="flex items-center">
                          <span className="mr-2">$102,331</span>
                          <span className="text-xs text-green-600">+35%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Define MessageSquare and Bookmark components since they're used but not imported
const MessageSquare = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </svg>
);

const Bookmark = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
  </svg>
);

export default Analytics;
