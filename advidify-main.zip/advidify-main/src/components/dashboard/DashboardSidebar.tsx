
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from "@/lib/utils";
import { LogOut, Share, Mic, FileText, BarChart3, Palette, Layout, Video } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';

const DashboardSidebar = () => {
  const location = useLocation();
  const { signOut } = useAuth();
  const { toast } = useToast();
  
  const isActive = (path: string) => {
    return location.pathname === `/dashboard${path}`;
  };
  
  const navItems = [
    { icon: Share, label: 'Publishing', path: '/publish' },
    { icon: Mic, label: 'Voice Generator', path: '/voice-generator' },
    { icon: Video, label: 'Video Generator', path: '/video-generator' },
    { icon: Layout, label: 'Templates', path: '/templates' },
    { icon: FileText, label: 'Script Generator', path: '/script-generator' },
    { icon: BarChart3, label: 'Analytics', path: '/analytics' },
    { icon: Palette, label: 'Custom Branding', path: '/custom-branding' },
  ];
  
  const handleSignOut = async () => {
    await signOut();
    toast({
      title: "Signed out successfully",
      description: "You have been signed out of your account"
    });
  };
  
  return (
    <aside className="bg-white w-64 hidden md:block shadow-sm border-r border-gray-200">
      <div className="h-full flex flex-col py-6">
        <div className="px-6 mb-8">
          <Link 
            to="/" 
            className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-600"
          >
            advidify
          </Link>
        </div>
        
        <nav className="flex-1 px-3 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={`/dashboard${item.path}`}
              className={cn(
                "flex items-center px-3 py-3 rounded-md text-sm font-medium transition-colors",
                isActive(item.path)
                  ? "bg-primary/10 text-primary" 
                  : "text-gray-700 hover:bg-gray-100"
              )}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.label}
            </Link>
          ))}
        </nav>
        
        <div className="px-3 mt-6 pt-6 border-t border-gray-200">
          <button
            onClick={handleSignOut}
            className="flex items-center w-full px-3 py-3 text-sm font-medium text-gray-700 rounded-md hover:bg-gray-100 transition-colors"
          >
            <LogOut className="h-5 w-5 mr-3" />
            Sign Out
          </button>
        </div>
      </div>
    </aside>
  );
};

export default DashboardSidebar;
