
import React, { useState, useEffect } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import VoiceSelector from './voice-generator/VoiceSelector';
import TextToVoiceConverter from './voice-generator/TextToVoiceConverter';

// Sample voices data - in a real app, this would come from your API
const voicesData = [
  { id: 'voice1', name: 'Sarah', gender: 'Female', accent: 'American', sample: 'https://example.com/sample1.mp3' },
  { id: 'voice2', name: 'Michael', gender: 'Male', accent: 'American', sample: 'https://example.com/sample2.mp3' },
  { id: 'voice3', name: 'Emma', gender: 'Female', accent: 'British', sample: 'https://example.com/sample3.mp3' },
  { id: 'voice4', name: 'James', gender: 'Male', accent: 'British', sample: 'https://example.com/sample4.mp3' },
  { id: 'voice5', name: 'Sophia', gender: 'Female', accent: 'Australian', sample: 'https://example.com/sample5.mp3' },
  { id: 'voice6', name: 'David', gender: 'Male', accent: 'Australian', sample: 'https://example.com/sample6.mp3' },
];

const VoiceGenerator = () => {
  const [selectedVoice, setSelectedVoice] = useState<string | null>(null);
  const [playingVoice, setPlayingVoice] = useState<string | null>(null);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  // Clean up audio when component unmounts
  useEffect(() => {
    return () => {
      if (audioElement) {
        audioElement.pause();
      }
    };
  }, [audioElement]);

  const handleSelectVoice = (voiceId: string) => {
    setSelectedVoice(voiceId);
    
    // Stop any playing sample
    if (audioElement) {
      audioElement.pause();
      setPlayingVoice(null);
    }
  };

  const handlePlaySample = (voiceId: string) => {
    // Stop any currently playing audio
    if (audioElement) {
      audioElement.pause();
    }
    
    // Find the voice sample URL
    const voice = voicesData.find(v => v.id === voiceId);
    if (!voice) return;
    
    // Create and play a new audio element
    const audio = new Audio(voice.sample);
    audio.onended = () => {
      setPlayingVoice(null);
    };
    
    audio.play().catch(error => {
      console.error("Error playing audio sample:", error);
      toast({
        title: "Playback Error",
        description: "Could not play the voice sample.",
        variant: "destructive",
      });
    });
    
    setAudioElement(audio);
    setPlayingVoice(voiceId);
  };

  const handlePauseSample = () => {
    if (audioElement) {
      audioElement.pause();
      setPlayingVoice(null);
    }
  };

  const handleGenerateAudio = async (text: string, voiceId: string): Promise<string> => {
    // In a real app, this would call your API to generate audio
    // For demo purposes, we're simulating a delay and returning a fixed URL
    return new Promise((resolve) => {
      setTimeout(() => {
        // In a real implementation, this would be the URL of the generated audio
        resolve(`https://example.com/generated-audio.mp3?text=${encodeURIComponent(text)}&voice=${voiceId}`);
      }, 2000);
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">AI Voice Generator</h1>
      </div>
      
      <Tabs defaultValue="voices" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="voices">Voice Selection</TabsTrigger>
          <TabsTrigger value="convert">Text to Speech</TabsTrigger>
        </TabsList>
        
        <TabsContent value="voices" className="space-y-4">
          <VoiceSelector
            voices={voicesData}
            selectedVoice={selectedVoice}
            onSelectVoice={handleSelectVoice}
            playingVoice={playingVoice}
            onPlaySample={handlePlaySample}
            onPauseSample={handlePauseSample}
          />
        </TabsContent>
        
        <TabsContent value="convert" className="space-y-4">
          <TextToVoiceConverter
            selectedVoice={selectedVoice}
            onGenerateAudio={handleGenerateAudio}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default VoiceGenerator;
