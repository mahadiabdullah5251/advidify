
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { 
  Wand2, 
  RefreshCw, 
  Copy, 
  CheckCheck,
  Save
} from 'lucide-react';
import { toast } from "@/hooks/use-toast";

// Sample script templates
const scriptTemplates = [
  { id: 1, name: "Problem-Solution", description: "Highlights a problem and presents your product as the solution" },
  { id: 2, name: "Before-After", description: "Shows transformation by using your product" },
  { id: 3, name: "Feature-Benefit", description: "Outlines key features and their benefits to users" },
  { id: 4, name: "Testimonial", description: "Uses customer reviews and experiences to build trust" },
  { id: 5, name: "How-To", description: "Demonstrates how to use your product effectively" }
];

const ScriptGenerator = () => {
  const [productName, setProductName] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [keyBenefits, setKeyBenefits] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null);
  const [generatedScript, setGeneratedScript] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [savedScripts, setSavedScripts] = useState<string[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!productName || !productDescription || !targetAudience || !selectedTemplate) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields and select a template.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsGenerating(true);
      
      // In a real app, this would be an API call to your backend or AI service
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Sample generated script based on template and inputs
      const scriptExamples: Record<number, string> = {
        1: `[Problem Setup]\nAre you tired of ${targetAudience.toLowerCase()} struggling with ineffective products?\n\n[Solution Introduction]\nIntroducing ${productName}, the revolutionary solution designed to ${productDescription.toLowerCase()}.\n\n[Benefits]\n${keyBenefits}\n\n[Call to Action]\nTry ${productName} today and experience the difference!`,
        2: `[Before State]\nBefore ${productName}: ${targetAudience} were struggling with low results.\n\n[Transformation]\nAfter using ${productName}: ${keyBenefits}\n\n[Product Details]\n${productDescription}\n\n[Call to Action]\nReady to transform your experience? Get ${productName} now!`,
        3: `[Introduction]\nPresenting ${productName}, specially crafted for ${targetAudience}.\n\n[Key Features & Benefits]\n${productDescription}\n\n${keyBenefits}\n\n[Closing Statement]\nElevate your experience with ${productName} today!`,
        4: `[Customer Voice]\n"Before trying ${productName}, I was skeptical. But after seeing how it ${productDescription.toLowerCase()}, I'm completely sold!"\n\n[Product Introduction]\n${productName} is designed specifically for ${targetAudience}.\n\n[Benefits]\n${keyBenefits}\n\n[Call to Action]\nJoin thousands of satisfied customers and try ${productName} today!`,
        5: `[Introduction]\nToday, I'll show you how to get the most out of ${productName}, perfect for ${targetAudience}.\n\n[Product Overview]\n${productDescription}\n\n[Step-by-Step Guide]\n1. Unbox your ${productName}\n2. Follow the setup instructions\n3. Start enjoying these benefits: ${keyBenefits}\n\n[Closing]\nThere you have it! A simple guide to transform your experience with ${productName}.`
      };
      
      setGeneratedScript(scriptExamples[selectedTemplate]);
      toast({
        title: "Script Generated",
        description: "Your AI script has been generated successfully!",
      });
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: "Failed to generate script. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyScript = () => {
    if (!generatedScript) return;
    
    navigator.clipboard.writeText(generatedScript);
    setCopied(true);
    
    toast({
      title: "Copied to Clipboard",
      description: "Script has been copied to your clipboard.",
    });
    
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveScript = () => {
    if (!generatedScript) return;
    
    setSavedScripts(prev => [...prev, generatedScript]);
    
    toast({
      title: "Script Saved",
      description: "Your script has been saved to your collection.",
    });
  };

  const handleTemplateSelect = (templateId: number) => {
    setSelectedTemplate(templateId);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">AI Script Generator</h1>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Input Form */}
          <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-xl border border-gray-200">
            <h2 className="text-xl font-semibold mb-4">Script Details</h2>
            
            <div>
              <Label htmlFor="productName">Product Name</Label>
              <Input
                id="productName"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="Enter your product name"
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="productDescription">Product Description</Label>
              <Textarea
                id="productDescription"
                value={productDescription}
                onChange={(e) => setProductDescription(e.target.value)}
                placeholder="What does your product do? What problem does it solve?"
                className="mt-1"
                rows={3}
              />
            </div>
            
            <div>
              <Label htmlFor="targetAudience">Target Audience</Label>
              <Input
                id="targetAudience"
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                placeholder="Who is your ideal customer?"
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="keyBenefits">Key Benefits</Label>
              <Textarea
                id="keyBenefits"
                value={keyBenefits}
                onChange={(e) => setKeyBenefits(e.target.value)}
                placeholder="List the main benefits of your product"
                className="mt-1"
                rows={3}
              />
            </div>
            
            <div className="flex justify-end">
              <Button 
                type="submit"
                disabled={isGenerating}
                className="bg-primary hover:bg-primary/90"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Wand2 className="h-4 w-4 mr-2" />
                    Generate Script
                  </>
                )}
              </Button>
            </div>
          </form>
          
          {/* Generated Script */}
          {generatedScript && (
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Generated Script</h2>
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleCopyScript}
                  >
                    {copied ? (
                      <>
                        <CheckCheck className="h-4 w-4 mr-2" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </>
                    )}
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleSaveScript}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                </div>
              </div>
              <div className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap">
                {generatedScript}
              </div>
            </div>
          )}
        </div>
        
        {/* Script Templates */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Script Templates</h2>
          <div className="space-y-3">
            {scriptTemplates.map(template => (
              <Card 
                key={template.id}
                className={`cursor-pointer transition-all ${
                  selectedTemplate === template.id ? 'ring-2 ring-primary bg-primary/5' : 'hover:border-primary/50'
                }`}
                onClick={() => handleTemplateSelect(template.id)}
              >
                <CardContent className="p-4">
                  <h3 className="font-medium">{template.name}</h3>
                  <p className="text-sm text-gray-500">{template.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {savedScripts.length > 0 && (
            <div className="mt-6">
              <h2 className="text-xl font-semibold mb-3">Saved Scripts</h2>
              <div className="space-y-2">
                {savedScripts.map((script, index) => (
                  <div key={index} className="text-sm border border-gray-200 rounded-md p-3 bg-white">
                    {script.substring(0, 100)}...
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ScriptGenerator;
