
import React from 'react';
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const pricingPlans = [
  {
    name: "Starter",
    price: 49,
    period: "per month",
    description: "Perfect for small e-commerce stores getting started with video ads.",
    features: [
      "10 AI video ads per month",
      "5 voice options",
      "Basic templates library",
      "720p video quality",
      "Email support"
    ],
    highlighted: false,
    buttonText: "Start Free Trial"
  },
  {
    name: "Professional",
    price: 99,
    period: "per month",
    description: "Ideal for growing brands that need more content and customization.",
    features: [
      "30 AI video ads per month",
      "All voice options",
      "Full template library",
      "1080p video quality",
      "Custom branding",
      "Priority support",
      "Performance analytics"
    ],
    highlighted: true,
    buttonText: "Start Free Trial"
  },
  {
    name: "Business",
    price: 199,
    period: "per month",
    description: "For established brands with high-volume content needs.",
    features: [
      "100 AI video ads per month",
      "All voice options",
      "Full template library",
      "1080p video quality",
      "Custom branding",
      "Priority support",
      "Performance analytics",
      "API access",
      "Dedicated account manager"
    ],
    highlighted: false,
    buttonText: "Contact Sales"
  }
];

const PricingSection = () => {
  return (
    <section id="pricing" className="py-20 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute right-0 top-1/3 w-72 h-72 bg-blue-50 rounded-full blur-3xl -z-10" />
      <div className="absolute left-0 bottom-1/3 w-64 h-64 bg-purple-50 rounded-full blur-3xl -z-10" />
      
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="text-center mb-16 animate-fade-in">
          <span className="inline-block px-3 py-1 text-xs font-medium text-primary bg-primary/10 rounded-full mb-4">
            Pricing Plans
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-balance mb-4">
            Choose the Perfect Plan for Your Needs
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Flexible plans to help you create engaging UGC-style video ads, regardless of your budget or requirements.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingPlans.map((plan, index) => (
            <div
              key={index}
              className={`rounded-2xl p-8 transition-all duration-300 hover:translate-y-[-5px] relative animate-fade-in ${
                plan.highlighted 
                  ? 'bg-gradient-to-b from-primary/10 to-purple-50 border-2 border-primary' 
                  : 'premium-card border border-gray-100'
              }`}
              style={{ animationDelay: `${0.1 * index}s` }}
            >
              {plan.highlighted && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 px-4 py-1 bg-primary text-white text-sm font-medium rounded-full">
                  Most Popular
                </div>
              )}
              
              <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
              <div className="flex items-baseline mb-6">
                <span className="text-4xl font-bold">${plan.price}</span>
                <span className="text-gray-500 ml-2">{plan.period}</span>
              </div>
              <p className="text-gray-600 mb-6">{plan.description}</p>
              
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 shrink-0" />
                    <span className="text-gray-600 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button 
                className={`w-full ${
                  plan.highlighted 
                    ? 'bg-primary hover:bg-primary/90' 
                    : 'bg-gray-900 hover:bg-gray-800'
                }`}
              >
                {plan.buttonText}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
