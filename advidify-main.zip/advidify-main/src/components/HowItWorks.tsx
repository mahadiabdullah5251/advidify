
import React from 'react';

const steps = [
  {
    number: "01",
    title: "Upload Product Images",
    description: "Simply upload your product images to our platform. We'll automatically enhance them for video.",
    image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7"
  },
  {
    number: "02",
    title: "Choose Template & Voice",
    description: "Select from our library of UGC-style templates and realistic AI voices that match your brand.",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
  },
  {
    number: "03",
    title: "Customize Your Script",
    description: "Use our AI script generator or customize the text to highlight your product's key benefits.",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6"
  },
  {
    number: "04",
    title: "Generate & Download",
    description: "Our AI creates your video in minutes. Preview, make adjustments, and download the final result.",
    image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b"
  }
];

const HowItWorks = () => {
  return (
    <section id="how-it-works" className="py-20 bg-gradient-to-b from-white to-blue-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="text-center mb-16 animate-fade-in">
          <span className="inline-block px-3 py-1 text-xs font-medium text-primary bg-primary/10 rounded-full mb-4">
            Simple Process
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-balance mb-4">
            Create UGC Video Ads in Minutes
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our intuitive workflow makes it easy to transform your product images into engaging video content without any technical expertise.
          </p>
        </div>
        
        <div className="space-y-24">
          {steps.map((step, index) => (
            <div 
              key={index}
              className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center gap-12 animate-fade-in`}
              style={{ animationDelay: `${0.2 * index}s` }}
            >
              <div className="lg:w-1/2 relative">
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-purple-100/30 rounded-3xl transform rotate-3 scale-105" />
                <div className="premium-card overflow-hidden aspect-video rounded-2xl relative">
                  <img 
                    src={step.image} 
                    alt={step.title}
                    className="w-full h-full object-cover rounded-2xl transition-transform duration-700 hover:scale-105"
                    loading="lazy"
                  />
                </div>
              </div>
              
              <div className="lg:w-1/2 space-y-4">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary font-semibold">
                  {step.number}
                </div>
                <h3 className="text-2xl font-bold">{step.title}</h3>
                <p className="text-gray-600 max-w-md">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
