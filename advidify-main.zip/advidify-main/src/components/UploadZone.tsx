
import React, { useState, useRef } from 'react';
import { cn } from '@/lib/utils';

interface UploadZoneProps {
  onImageSelected: (file: File) => void;
  className?: string;
}

const UploadZone = ({ onImageSelected, className }: UploadZoneProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragging) {
      setIsDragging(true);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    handleFiles(files);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      handleFiles(files);
    }
  };

  const handleFiles = (files: FileList) => {
    if (files.length > 0) {
      const file = files[0];
      const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
      
      if (validTypes.includes(file.type)) {
        onImageSelected(file);
      } else {
        alert('Please upload a valid image file (JPEG, PNG, or WebP)');
      }
    }
  };

  const handleClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div
      className={cn(
        'relative cursor-pointer transition-all duration-300 ease-in-out',
        'rounded-xl border-2 border-dashed p-8 text-center',
        isDragging 
          ? 'border-primary bg-primary/5 scale-[1.02]' 
          : isHovering 
            ? 'border-gray-400 bg-gray-50' 
            : 'border-gray-300 bg-gray-50/50',
        className
      )}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onClick={handleClick}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileInput}
        accept="image/jpeg, image/png, image/jpg, image/webp"
        className="hidden"
      />
      
      <div className="flex flex-col items-center justify-center gap-3">
        <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${isDragging ? 'bg-primary/20 text-primary' : 'bg-gray-100 text-gray-500'}`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7" />
            <line x1="16" x2="22" y1="5" y2="5" />
            <line x1="19" x2="19" y1="2" y2="8" />
            <circle cx="9" cy="9" r="2" />
            <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
          </svg>
        </div>
        <div>
          <p className={`font-medium mb-1 ${isDragging ? 'text-primary' : 'text-gray-700'}`}>
            {isDragging ? 'Drop your image here' : 'Upload Product Image'}
          </p>
          <p className="text-sm text-gray-500">
            Drag & drop or click to browse
          </p>
          <p className="mt-2 text-xs text-gray-400">
            Supports JPG, PNG, WebP (Max 5MB)
          </p>
        </div>
      </div>
    </div>
  );
};

export default UploadZone;
