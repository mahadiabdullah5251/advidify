
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import ProfileDropdown from './ProfileDropdown';
import { useAuth } from '@/context/AuthContext';
import { Link } from 'react-router-dom';

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const { user } = useAuth();
  
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out py-4 px-6 md:px-10",
      scrolled 
        ? "bg-white/80 backdrop-blur-lg shadow-sm" 
        : "bg-transparent"
    )}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <Link to="/" className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-600">
            advidify
          </Link>
        </div>
        
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#features" className="text-sm font-medium text-gray-700 hover:text-primary transition-colors">
            Features
          </a>
          <a href="#how-it-works" className="text-sm font-medium text-gray-700 hover:text-primary transition-colors">
            How It Works
          </a>
          <a href="#pricing" className="text-sm font-medium text-gray-700 hover:text-primary transition-colors">
            Pricing
          </a>
          {user && (
            <Link to="/dashboard" className="text-sm font-medium text-gray-700 hover:text-primary transition-colors">
              Dashboard
            </Link>
          )}
        </nav>
        
        <div className="flex items-center space-x-4">
          <ProfileDropdown />
          
          {!user && (
            <Button 
              className="bg-primary hover:bg-primary/90 transition-colors"
              onClick={() => window.location.href = '/auth'}
            >
              Get Started
            </Button>
          )}
          
          {user && (
            <Link to="/dashboard">
              <Button className="bg-primary hover:bg-primary/90 transition-colors">
                Dashboard
              </Button>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
